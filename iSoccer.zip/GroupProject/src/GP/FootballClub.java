package GP;

import java.util.Objects;

public class FootballClub extends SportsClub {

    private int winCount;
    private int drawCount;
    private int defeatCount;
    private int scoredGoalsCount;
    private int receivedGoalsCount;
    private int points;
    private int matchesPlayed;

    public int getWinCount(){
        return winCount;
    }

    public int getDrawCount() {
        return drawCount;
    }

    public int getDefeatCount(){
        return defeatCount;
    }

    public int getScoredGoalsCount() {
        return scoredGoalsCount;
    }

    public int getReceivedGoalsCount() {
        return receivedGoalsCount;
    }

    public int getPoints() {
        return points;
    }

    public int getMatchesPlayed() {
        return matchesPlayed;
    }

    public void setWinCount(int i) {
        winCount=i;
    }

    public void setDrawCount(int i){
        drawCount = i;
    }

    public void setDefeatCount(int i) {
        defeatCount=i;
    }

    public void setScoredGoalsCount(int i){
        scoredGoalsCount = i;
    }

     public void setRecievedGoalsCount(int i){
        receivedGoalsCount = i;
    }

     public void setPoints(int i){
        points = i;
    }
    public void setMatchesPlayed(int i){
        matchesPlayed = i;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        FootballClub that = (FootballClub) o;
        return winCount == that.winCount && drawCount == that.drawCount && defeatCount == that.defeatCount && scoredGoalsCount == that.scoredGoalsCount && receivedGoalsCount == that.receivedGoalsCount && points == that.points && matchesPlayed == that.matchesPlayed;
    }

    @Override
    public int hashCode() {
        return Objects.hash(winCount, drawCount, defeatCount, scoredGoalsCount, receivedGoalsCount, points, matchesPlayed);
    }

    @Override
    public String toString() {
        return "FootballClub{" +
                "winCount=" + winCount +
                ", drawCount=" + drawCount +
                ", defeatCount=" + defeatCount +
                ", scoredGoalsCount=" + scoredGoalsCount +
                ", receivedGoalsCount=" + receivedGoalsCount +
                ", points=" + points +
                ", matchesPlayed=" + matchesPlayed +
                '}';
    }
}
