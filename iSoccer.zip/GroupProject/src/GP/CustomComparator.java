package GP;

import java.util.Comparator;

public class CustomComparator implements Comparator<FootballClub> {


    @Override
    public int compare(FootballClub o1, FootballClub o2) {
        return 0;
    }

    public class FootballClubComparator implements Comparator<FootballClub> {

        @Override
        public int compare(FootballClub club1, FootballClub club2) {
            int pointsDiff = Integer.compare(club2.getPoints(), club1.getPoints());
            if (pointsDiff != 0) {
                return pointsDiff;
            }
            int goalDiff = Integer.compare((club2.getScoredGoalsCount() - club2.getReceivedGoalsCount()), (club1.getScoredGoalsCount() - club1.getReceivedGoalsCount()));
            if (goalDiff != 0) {
                return goalDiff;
            }
            return club1.getName().compareTo(club2.getName());
        }
    }

}
