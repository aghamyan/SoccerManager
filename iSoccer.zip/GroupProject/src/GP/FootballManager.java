package GP;

public class FootballManager {

    public static void main(String[] args) {
        SoccerManager soccerManager = new SoccerManager(10);


    }
}