package GP;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;


public class SoccerManager {

    private final int numberOfClubs;

    @Override
    public String toString() {
        return "SoccerManager{" +
                "numberOfClubs=" + numberOfClubs +
                ", league=" + league +
                ", scanner=" + scanner +
                ", matches=" + matches +
                ", balance=" + balance +
                ", betAmount=" + betAmount +
                '}';
    }

    private final ArrayList<FootballClub> league;

    public SoccerManager(int numberOfClubs, ArrayList<FootballClub> league, Scanner scanner, ArrayList<Match> matches) {
        this.numberOfClubs = numberOfClubs;
        this.league = league;
        this.scanner = scanner;
        this.matches = matches;
    }

    private final Scanner scanner;
    private final ArrayList<Match> matches;

    public SoccerManager(int numberOfClubs) {

        this.numberOfClubs = numberOfClubs;
        league = new ArrayList<>();
        matches = new ArrayList<>();
        scanner = new Scanner(System.in);
        displayMenu();
    }


    private void displayMenu() {

        while(true) {
            System.out.println(" Menu: ");
            System.out.println("Create team (press 1)");
            System.out.println("Delete team  (press 2)");
            System.out.println("Display Statistics (press 3)");
            System.out.println("Display the Championship Table (press 4)");
            System.out.println("Add a Match (press 5)");
            System.out.println("Display Calendar (press 6)");
            System.out.println("Simulate Match (Press 7)");
            System.out.println("Display squads (press 8)");
            System.out.println("Penatly game (press 9)");
            String line = scanner.nextLine();
            int command = 0;
            try {
                command = Integer.parseInt(line);
            } catch (Exception e) {
        }

            switch(command) {
                case 1 :
                   addTeam();
            break;
                case 2 :
                    deleteTeam();
                    break;
                case 3 :
                    displayStatistics();
                  break;
                case 4 :
                    displayLeagueTable();
                  break;
                case 5:
                    addPlayedMatch();
                   break;
                case 6:
                    displayCalendar();
                   break;
                case 7:
                    simulateMatch();
                    break;
                case 8:
                    displayClubLogo();
                    break;
                case 9:
                    playSoccerPenaltyGame();
                    break;
            default:
            System.out.println("Wrong Command");
        }

    }
   }


    private int balance = 1000;
    private int betAmount = 0;

    private void playSoccerPenaltyGame() {
        System.out.println("Welcome to the Soccer Penalty Game!");
        System.out.println("You have been given $" + (balance-betAmount) + " to bet. If you score a penalty, your bet will be doubled.");
        System.out.println("Please choose where to shoot (left, center, right):");
        String shotPosition = scanner.nextLine();


        boolean validInput = false;
        while (!validInput) {
            System.out.println("Please enter your bet amount (integer):");
            try {
                betAmount = Integer.parseInt(scanner.nextLine());
                if (betAmount > balance) {
                    System.out.println("You don't have enough balance to place this bet. Please enter a lower amount.");
                } else {
                    validInput = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter an integer.");
            }
        }

        String[] goalkeeperPositions = {"left", "center", "right"};
        int goalkeeperPositionIndex = (int)(Math.random() * goalkeeperPositions.length);
        String goalkeeperPosition = goalkeeperPositions[goalkeeperPositionIndex];
        System.out.println("The goalkeeper has jumped to " + goalkeeperPosition + ".");
        boolean goal = (goalkeeperPosition.equals(shotPosition)) ? false : true;
        if (goal) {
            int winnings = betAmount * 2;
            System.out.println("You scored a goal! You have won $" + winnings + ".");
            balance += winnings;
        } else {
            System.out.println("The goalkeeper saved your shot!");
            balance -= betAmount;
        }
        System.out.println("Your current balance is $" + (balance-betAmount) + ".");
        System.out.println("Do you want to continue playing? (yes/no)");
        String continuePlaying = scanner.nextLine();
        if (continuePlaying.equalsIgnoreCase("yes")) {
            playSoccerPenaltyGame();
        } else {
            System.out.println("Thank you for playing! Your final balance is $" + (balance-betAmount) + ".");
        }
    }


    private void readFileForClub() {
        System.out.print("Enter the name of the club: ");
        String clubName = scanner.nextLine();
        String fileName = clubName.toLowerCase() + ".txt";
        try {
            Scanner fileScanner = new Scanner(new File(fileName));
            while (fileScanner.hasNextLine()) {
                System.out.println(fileScanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found for " + clubName);
        }
    }
    private void displayClubLogo() {
        try {
            System.out.println("Enter the name of the club: ");
            String clubName = scanner.nextLine();
            String imagePath = clubName.toLowerCase() + ".jpg";
            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                BufferedImage image = ImageIO.read(imageFile);
                ImageIcon icon = new ImageIcon(image);
                JLabel label = new JLabel(icon);
                JFrame frame = new JFrame();
                frame.add(label);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            } else {
                System.out.println("Logo not found");
            }
        } catch (IOException e) {
            System.out.println("Error displaying club logo");
            e.printStackTrace();
        }
    }




    private void simulateMatch() {


       // System.out.println("Match generated successfully:");
       // System.out.println(teamA.getName() + " " + teamAScore + " - " + teamBScore + " " + teamB.getName());


            int totalGoals;
            int teamAScore = 0;
            int teamBScore =0;
            int aFreeKicks = 0;
            int bFreeKicks = 0;
            int aCorners = 0;
            int bCorners = 0;
            int aOffsides = 0;
            int bOffsides = 0;
            int aYellowCards = 0;
            int bYellowCards = 0;
            int aRedCards = 0;
            int bRedCards = 0;
            int aPenalties = 0;
            int bPenalties = 0;
            int redCardShown = 0;
            int event;
            int minutes = 3;


        if (league.size() < 2) {
            System.out.println("No enough teams.");
            return;
        }

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the name of team A: ");
        String teamAName = input.nextLine().toLowerCase();

        System.out.print("Enter the name of team B: ");
        String teamBName = input.nextLine().toLowerCase();

        FootballClub teamA = null;
        FootballClub teamB = null;

        for (FootballClub club : league) {
            if (club.getName().equals(teamAName)) {
                teamA = club;
            }
            if (club.getName().equals(teamBName)) {
                teamB = club;
            }
        }

        if (teamA == null || teamB == null) {
            System.out.println("Error: One or both of the teams selected are not in the league.");
            simulateMatch();
        } else {

        }




        while (teamA.equals(teamB)) {
            teamB = league.get((int) (Math.random() * league.size()));
        }

        // Generate random scores for the two teams


        // Create a new match object with the generated data
        Match match = new Match();
        match.setTeamA(teamA);
        match.setTeamB(teamB);
        match.setTeamAScore(teamAScore);
        match.setTeamBScore(teamBScore);
        match.setDate(new Date());

        // Update the statistics of the two teams based on the match result
        teamA.setMatchesPlayed(teamA.getMatchesPlayed() + 1);
        teamB.setMatchesPlayed(teamB.getMatchesPlayed() + 1);
        teamA.setScoredGoalsCount(teamA.getScoredGoalsCount() + teamAScore);
        teamB.setScoredGoalsCount(teamB.getScoredGoalsCount() + teamBScore);
        teamA.setRecievedGoalsCount(teamA.getReceivedGoalsCount() + teamBScore);
        teamB.setRecievedGoalsCount(teamB.getReceivedGoalsCount() + teamAScore);

        if (teamAScore > teamBScore) {
            teamA.setWinCount(teamA.getWinCount() + 1);
            teamA.setPoints(teamA.getPoints() + 3);
            teamB.setDefeatCount(teamB.getDefeatCount() + 1);
        } else if (teamAScore < teamBScore) {
            teamB.setWinCount(teamB.getWinCount() + 1);
            teamB.setPoints(teamB.getPoints() + 3);
            teamA.setDefeatCount(teamA.getDefeatCount() + 1);
        } else {
            teamA.setDrawCount(teamA.getDrawCount() + 1);
            teamA.setPoints(teamA.getPoints() + 1);
            teamB.setDrawCount(teamB.getDrawCount() + 1);
            teamB.setPoints(teamB.getPoints() + 1);
        }

        // Add the match
        matches.add(match);

            // Simulate the match
            System.out.println("The match begins!");
            for (int i = 0; i < 90; i++) {
                minutes++;
                event = (int)(Math.random()*100);

                if (Math.random() < 0.10) {

                    if (Math.random() < 0.15 && aRedCards < 2) {
                        System.out.println(minutes + "' Red card for " + teamA.getName());
                        aRedCards++;
                    } else if (Math.random()<0.15 && bRedCards < 2) {
                        System.out.println(minutes + "' Red card for " + teamB.getName());
                        bRedCards++;
                    }
                    else if ((Math.random()<0.60 )){
                        if (Math.random()<0.30){
                            System.out.println(minutes + "'Goal for " + teamA.getName());
                            teamAScore++;
                        }
                        else if (Math.random()<0.30) {
                            System.out.println(minutes + "' Goal for " + teamB.getName());
                            teamBScore++;
                        }
                    }
                } else if (Math.random() < 0.15) {
                    // 15% chance of a yellow card
                    if (Math.random() < 0.5 && aYellowCards < 7) {
                        System.out.println(minutes + "' Yellow card for "+ teamA.getName());
                        aYellowCards++;
                    } else if (bYellowCards < 7) {
                        System.out.println(minutes + "' Yellow card for "+ teamB.getName());
                        bYellowCards++;
                    }
                } else if (Math.random() < 0.1 && aPenalties < 1 && bPenalties < 1) {

                    if (Math.random() < 0.5) {
                        System.out.println(minutes + "' Penalty for  " + teamA.getName());
                        aPenalties++;
                        if (Math.random() < 0.8) {
                            // 80% chance of scoring a penalty
                            System.out.println(minutes + "'GOAL for " + teamA.getName());
                            teamAScore++;
                        } else {
                            System.out.println(minutes + "' Missed penalty by " + teamA.getName());
                        }
                    } else {
                        System.out.println(minutes + "' Penalty for " + teamB.getName());
                        bPenalties++;
                        if (Math.random() < 0.8) {
                            // 80% chance of scoring a penalty
                            System.out.println(minutes + "' GOAL for " + teamB.getName());
                            teamBScore++;
                        } else {
                            System.out.println(minutes + "' Missed penalty by " + teamB.getName());
                        }
                    }
                } else if (Math.random() < 0.15) {
                    // 15% chance of a corner
                    if (Math.random() < 0.5) {
                        System.out.println(minutes + "' Corner for " + teamA.getName());
                        aCorners++;
                    } else {
                        System.out.println(minutes + "' Corner for " + teamB.getName());
                        bCorners++;
                    }
                } else if (Math.random() < 0.12) {
                    if (Math.random() < 0.3) {
                        System.out.println(minutes + "' Offside for " + teamA.getName());
                        aOffsides++;
                    } else {
                        System.out.println(minutes + "' Offside for " + teamB.getName());
                        bOffsides++;
                    }
                } else if (Math.random() < 0.3) {
// 30% chance of a free kick
                    if (Math.random() < 0.40) {
                        System.out.println(minutes + "' Free kick for " + teamA.getName());
                        aFreeKicks++;
                    } else {
                        System.out.println(minutes + "' Free kick for " + teamB.getName());
                        bFreeKicks++;
                    }
                } else {


                }


                // Check if a team has scored 3 goals or if both teams have scored 2 goals each, then end the match should end. this is to limit unlogic scores in the game
                if (teamAScore >= 5 || teamBScore >= 5 || (teamAScore == 5 && teamBScore == 5 && minutes >= 90)) {
                    System.out.println("The match has ended!");
                    break;
                }
            }

        System.out.println("Final score: " + teamA.getName().toUpperCase() +" " + teamAScore + " - " + teamBScore + " " +teamB.getName().toUpperCase());
        System.out.println("Team A statistics: Free kicks " + aFreeKicks + ", Corners " + aCorners + ", Offsides " + aOffsides + ", Yellow cards " + aYellowCards + ", Red cards " + aRedCards + ", Penalties " + aPenalties);
        System.out.println("Team B statistics: Free kicks " + bFreeKicks + ", Corners " + bCorners + ", Offsides " + bOffsides + ", Yellow cards " + bYellowCards + ", Red cards " + bRedCards + ", Penalties " + bPenalties);

    }


    private void addTeam() {
        if (league.size() == numberOfClubs) {
            System.out.println("League is full");
            return;
        }

        FootballClub club = new FootballClub();
        System.out.println("Insert Club Name: ");
        String line = scanner.nextLine().toLowerCase();
        club.setName(line);

        if (league.contains(club)) {
            System.out.println("This club is already in the league");
            return;
        }
        System.out.println("Insert Club Location: ");
        line = scanner.nextLine();
        club.setLocation(line);
        league.add(club);
    }


    private void deleteTeam() {
        System.out.println("Insert club name: ");
        String line = scanner.nextLine();
         for(FootballClub club : league) {
             if(club.getName().equals(line)){
                 league.remove(club);
                 System.out.println("Club "+ club.getName()+" removed");
                 return;
             }
         }
         System.out.println("There is no such club");
    }

    private void displayStatistics() {

        System.out.println("Insert club name: ");
        String line = scanner.nextLine().toLowerCase();
         for (FootballClub club : league) {
             if(club.getName().equals(line)){
                 System.out.println("Club " + club.getName()+ " matches won: " + club.getWinCount());
                 System.out.println("Club " + club.getName()+ " matches lost: " + club.getDefeatCount());
                 System.out.println("Club " + club.getName()+ " matches draw: " + club.getDrawCount());
                 System.out.println("Club " + club.getName()+ " scored goals: " + club.getScoredGoalsCount());
                 System.out.println("Club " + club.getName()+ " missed goals: " + club.getReceivedGoalsCount());
                 System.out.println("Club " + club.getName()+ " points: " + club.getPoints());
                 System.out.println("Club " + club.getName()+ " matches played: " + club.getMatchesPlayed());
                 return;
             }
         }
         System.out.println("There is no such club");
    }

    private void displayLeagueTable() {

        Collections.sort(league, new CustomComparator());
        for(FootballClub club : league) {
            System.out.println("Club: " + club.getName()+" Points: "+ club.getPoints()+" goal difference: "+ (club.getScoredGoalsCount()-club.getReceivedGoalsCount()));
    }
  }

    private void addPlayedMatch(){
        System.out.println("Enter date (format mm-dd-yyyy): ");
        String line = scanner.nextLine();
        Date date;
        try {
            date = new SimpleDateFormat("MM-dd-yyyy").parse(line);
        } catch (ParseException ex) {
            System.out.println("You have to enter date in format mm-dd-yyyy");
            return;
        }
        System.out.println("Enter Home Team: ");
        line = scanner.nextLine().toLowerCase();
        FootballClub home = null;
          for(FootballClub club : league){
              if(club.getName().equals(line))
                  home = club;
          }
          if (home == null) {
              System.out.println("No such club in league");
              return;
          }
          System.out.println("Enter Away Team: ");
          line = scanner.nextLine().toLowerCase();
          FootballClub away = null;
           for(FootballClub club : league){
              if(club.getName().equals(line))
                  away = club;
          }
           if (away == null) {
              System.out.println("No such club in league");
              return;
          }

           System.out.println("Enter home team goals: ");
           line = scanner.nextLine();
           int homeGoals = -1;
             try {
                 homeGoals = Integer.parseInt(line);
             } catch (Exception e) {
    }
         if (homeGoals == -1) {
             System.out.println("You have to enter number of goals");
             return;
         }

         System.out.println("Enter away team goals: ");
           line = scanner.nextLine();
           int awayGoals = -1;
             try {
                 awayGoals = Integer.parseInt(line);
             } catch (Exception e) {
    }

         if (awayGoals == -1) {
             System.out.println("You have to enter number of goals");
             return;
         }


         Match match = new Match();
         match.setDate(date);
         match.setTeamA(home);
         match.setTeamB(away);
         match.setTeamAScore(awayGoals);
         match.setTeamBScore(homeGoals);
         matches.add(match);
         home.setScoredGoalsCount(home.getScoredGoalsCount()+homeGoals);
         away.setScoredGoalsCount(away.getScoredGoalsCount()+awayGoals);
         home.setRecievedGoalsCount(home.getReceivedGoalsCount()+awayGoals);
         away.setRecievedGoalsCount(away.getReceivedGoalsCount()+homeGoals);
         home.setMatchesPlayed(home.getMatchesPlayed()+1);
         away.setMatchesPlayed(away.getMatchesPlayed()+1);

         if (homeGoals > awayGoals) {
             home.setPoints(home.getPoints()+3);
             home.setWinCount(home.getWinCount()+1);
             away.setDefeatCount(away.getDefeatCount()+1);
         }

         else if (homeGoals < awayGoals) {
             away.setPoints(away.getPoints()+3);
             away.setWinCount(away.getWinCount()+1);
             home.setDefeatCount(home.getDefeatCount()+1);
         }
         else {
             home.setPoints(home.getPoints());
             away.setPoints(away.getPoints());
             home.setDrawCount(home.getDrawCount()+1);
             away.setDrawCount(away.getDrawCount()+1);
         }
    }


    private void displayCalendar() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a year: ");
        int year = scanner.nextInt();

        System.out.println("Please enter a month (1-12): ");
        int month = scanner.nextInt();
        if (month < 1 || month > 12) {
            System.out.println("Invalid month");
            return;
        }

        String[] months = { "", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
        int[] daysInMonth = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        if (month == 2 && isLeapYear(year)) {
            daysInMonth[2] = 29;
        }

        System.out.println("    " + months[month] + " " + year);
        System.out.println("Su Mo Tu We Th Fr Sa");

        int dayOfWeek = dayOfWeek(month, 1, year);
        for (int i = 0; i < dayOfWeek; i++) {
            System.out.print("   ");
        }

        for (int day = 1; day <= daysInMonth[month]; day++) {
            if (day < 10) {
                System.out.print(" ");
            }
            System.out.print(day);
            if ((dayOfWeek + day) % 7 == 0 || day == daysInMonth[month]) {
                System.out.println();
            } else {
                System.out.print(" ");
            }
        }

        System.out.println("Please enter a day (1-" + daysInMonth[month] + "): ");
        int day = scanner.nextInt();
        if (day < 1 || day > daysInMonth[month]) {
            System.out.println("Invalid day");
            return;
        }

        System.out.println("Matches on " + months[month] + " " + day + ", " + year + ":");
        for (Match match : matches) {
            Calendar matchDate = Calendar.getInstance();
            matchDate.setTime(match.getDate());
            if (matchDate.get(Calendar.YEAR) == year && matchDate.get(Calendar.MONTH) == month - 1 && matchDate.get(Calendar.DAY_OF_MONTH) == day) {
                System.out.println(match.getTeamA().getName() + " " + match.getTeamAScore() + " : " + match.getTeamBScore() + " " + match.getTeamB().getName());
            }
        }
    }


    private int dayOfWeek(int month, int day, int year) {
        if (month < 3) {
            month += 12;
            year--;
        }
        int century = year / 100;
        int yearOfCentury = year % 100;
        int dayOfWeek = day + (13 * (month + 5) + yearOfCentury + (yearOfCentury / 4) + (century / 4) - 2 * century);
        dayOfWeek = ((dayOfWeek % 7) + 7) % 7;
        return dayOfWeek;
    }

    private boolean isLeapYear(int year) {
        if (year % 4 != 0) {
            return false;
        } else if (year % 400 == 0) {
            return true;
        } else if (year % 100 == 0) {
            return false;
        } else {
            return true;
        }
    }


        public int day(int M, int D, int Y) {
        int y = Y - (14 - M) / 12;
        int x = y + y/4 - y/100 + y/400;
        int m = M + 12 * ((14-M) / 12) - 2;
        int d = (D + x + (31*m)/12) % 7;
        return d;
    }


}





